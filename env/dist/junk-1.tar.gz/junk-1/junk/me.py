
def dump(anything):
    
    return anything


